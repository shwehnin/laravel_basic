<?php $__env->startSection("title"); ?> Create Category <?php $__env->stopSection(); ?>
<?php $__env->startSection("body"); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <nav aria-label="breadcrumb" class="bg-white">
                    <ol class="breadcrumb bg-white border border-faded">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('category.index')); ?>">Category</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Create</li>
                    </ol>
                </nav>
            </div>
            <div class="col-12">
                <div class="card">
                    <div class="card-header">Add New Category</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('category.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-inline">
                                <input type="text" name="title" class="form-control mr-3" placeholder="Category Name">
                                <button type="submit" class="btn btn-outline-secondary">Add Category</button>
                            </div>
                            <?php if ($errors->has("title")) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first("title"); ?>
                            <small class="text-danger font-weight-bold"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/blog/resources/views/category/create.blade.php ENDPATH**/ ?>