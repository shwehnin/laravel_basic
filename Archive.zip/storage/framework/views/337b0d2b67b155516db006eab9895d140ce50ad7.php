<div class="card menu">
    <div class="card-body">

        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary w-100 mb-3">Dashboard</a>

        <hr>

        <p class="font-weight-bold text-uppercase">Category Menu</p>

        <a href="<?php echo e(route('category.index')); ?>" class="btn btn-outline-secondary w-100 mb-3">Category List</a>

        <a href="<?php echo e(route('category.create')); ?>" class="btn btn-outline-secondary w-100 mb-3">Add Category</a>

        <hr>

        <p class="font-weight-bold text-uppercase">Post Menu</p>

        <a href="<?php echo e(route('post.index')); ?>" class="btn btn-outline-secondary w-100 mb-3">Post List</a>

        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-outline-secondary w-100 mb-3">Add Post</a>

        <hr>

    </div>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/blog/resources/views/layouts/menu.blade.php ENDPATH**/ ?>